const express = require('express');
const app = express ();
const path = require('path');

const port = 3000;

app.use(express.static(path.join(__dirname, 'public'))); //o path.join faz o programa buscar o caminho específico

app.get('/', (req, res) => {
    res.send('Hello Ituiutaba');
});


app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

app.use('/', (req, res) => {
    res.status(404).sendFile(path.join(__dirname, 'public', '404.html'))
});

app.listen (port, () => {
    console.log(`Server rodando na porta ${port}...`);
    console.log(__dirname);
});